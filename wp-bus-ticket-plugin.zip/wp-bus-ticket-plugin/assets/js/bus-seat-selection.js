jQuery(document).ready(function($) {
    $('#bus-seat-selection .seat').on('click', function() {
        $(this).toggleClass('selected');
    });
});
