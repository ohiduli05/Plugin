jQuery(document).ready(function($) {
    $('#bus-search-form').submit(function(event) {
        event.preventDefault();

        var from_city = $('input[name="from_city"]').val();
        var to_city = $('input[name="to_city"]').val();
        var date = $('input[name="date"]').val();

        $.ajax({
            url: busSearch.ajax_url,
            type: 'POST',
            data: {
                action: 'bus_search',
                from_city: from_city,
                to_city: to_city,
                date: date
            },
            success: function(response) {
                $('#bus-search-results').html(response);
            }
        });
    });
});
