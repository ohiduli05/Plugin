<?php
class Loyalty_Program {
    public function __construct() {
        add_action('woocommerce_order_status_completed', array($this, 'reward_points'), 10, 1);
    }

    public function reward_points($order_id) {
        $order = wc_get_order($order_id);
        $user_id = $order->get_user_id();
        $points = get_user_meta($user_id, '_loyalty_points', true);
        $points += 10; // Example: Add 10 points for each completed order
        update_user_meta($user_id, '_loyalty_points', $points);
    }
}
new Loyalty_Program();
