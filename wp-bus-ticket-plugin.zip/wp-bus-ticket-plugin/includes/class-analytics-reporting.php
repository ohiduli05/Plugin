<?php
class Analytics_Reporting {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_reports_menu'));
    }

    public function add_reports_menu() {
        add_menu_page('Bus Ticket Reports', 'Reports', 'manage_options', 'bus-ticket-reports', array($this, 'render_reports_page'), 'dashicons-chart-line', 6);
    }

    public function render_reports_page() {
        echo '<div class="wrap"><h1>Bus Ticket Reports</h1><p>Analytics and reports go here...</p></div>';
    }
}
new Analytics_Reporting();
