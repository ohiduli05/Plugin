<?php
class Route_Management {
    public function __construct() {
        add_action('init', array($this, 'create_route_post_type'));
    }

    public function create_route_post_type() {
        $labels = array(
            'name' => __('Routes', 'wp-bus-ticket-plugin'),
            'singular_name' => __('Route', 'wp-bus-ticket-plugin'),
            'add_new' => __('Add New', 'wp-bus-ticket-plugin'),
            'add_new_item' => __('Add New Route', 'wp-bus-ticket-plugin'),
            'edit_item' => __('Edit Route', 'wp-bus-ticket-plugin'),
            'new_item' => __('New Route', 'wp-bus-ticket-plugin'),
            'view_item' => __('View Route', 'wp-bus-ticket-plugin'),
            'search_items' => __('Search Routes', 'wp-bus-ticket-plugin'),
            'not_found' => __('No routes found', 'wp-bus-ticket-plugin'),
            'not_found_in_trash' => __('No routes found in Trash', 'wp-bus-ticket-plugin'),
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'custom-fields'),
            'menu_icon' => 'dashicons-admin-site',
        );

        register_post_type('route', $args);
    }
}
