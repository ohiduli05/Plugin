<?php
class Fleet_Management {
    public function __construct() {
        add_action('init', array($this, 'create_fleet_post_type'));
    }

    public function create_fleet_post_type() {
        $labels = array(
            'name' => __('Fleets', 'wp-bus-ticket-plugin'),
            'singular_name' => __('Fleet', 'wp-bus-ticket-plugin')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'supports' => array('title', 'editor', 'custom-fields')
        );

        register_post_type('fleet', $args);
    }
}
new Fleet_Management();
