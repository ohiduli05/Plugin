<?php
class Passenger_Feedback {
    public function __construct() {
        add_action('init', array($this, 'create_feedback_post_type'));
    }

    public function create_feedback_post_type() {
        $labels = array(
            'name' => __('Feedback', 'wp-bus-ticket-plugin'),
            'singular_name' => __('Feedback', 'wp-bus-ticket-plugin')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'supports' => array('title', 'editor', 'comments')
        );

        register_post_type('feedback', $args);
    }
}
new Passenger_Feedback();
