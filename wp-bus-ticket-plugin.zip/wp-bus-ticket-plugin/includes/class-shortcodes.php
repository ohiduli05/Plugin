<?php
class Shortcodes {
    public function __construct() {
        add_shortcode('bus_ticket_booking_form', array($this, 'render_booking_form'));
        add_shortcode('bus_search_form', array($this, 'render_search_form'));
    }

    public function render_booking_form() {
        return '<div>Booking Form HTML here</div>';
    }

    public function render_search_form() {
        $bus_search = new Bus_Search();
        return $bus_search->render_search_form();
    }
}
