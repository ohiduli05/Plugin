<?php
class WooCommerce_Integration {
    public function __construct() {
        add_action('woocommerce_after_shop_loop_item', array($this, 'add_to_cart_button'));
        add_action('woocommerce_cart_calculate_fees', array($this, 'add_booking_fee'));
        add_action('woocommerce_cart_totals_before_order_total', array($this, 'apply_discount_code'));
    }

    public function add_to_cart_button() {
        echo '<a href="' . esc_url(get_permalink()) . '?add-to-cart=' . get_the_ID() . '" class="button">Book Now</a>';
    }

    public function add_booking_fee() {
        WC()->cart->add_fee(__('Booking Fee', 'wp-bus-ticket-plugin'), 10);
    }

    public function apply_discount_code() {
        if (isset($_POST['discount_code'])) {
            $code = sanitize_text_field($_POST['discount_code']);
            WC()->cart->add_fee(__('Discount', 'wp-bus-ticket-plugin'), -10);
        }
    }
}
