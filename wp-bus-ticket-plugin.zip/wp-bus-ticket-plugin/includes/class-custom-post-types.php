<?php
class Custom_Post_Types {
    public function __construct() {
        add_action('init', array($this, 'create_post_types'));
    }

    public function create_post_types() {
        $this->create_post_type('bus', 'Buses', 'Bus');
        $this->create_post_type('route', 'Routes', 'Route');
        $this->create_post_type('schedule', 'Schedules', 'Schedule');
        $this->create_post_type('bus_operator', 'Bus Operators', 'Bus Operator');
    }

    private function create_post_type($type, $plural, $singular) {
        $labels = array(
            'name' => _x($plural, 'post type general name', 'wp-bus-ticket-plugin'),
            'singular_name' => _x($singular, 'post type singular name', 'wp-bus-ticket-plugin')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor')
        );

        register_post_type($type, $args);
    }
}
