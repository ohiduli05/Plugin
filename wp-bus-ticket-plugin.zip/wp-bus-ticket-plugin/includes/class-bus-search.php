<?php
class Bus_Search {
    public function __construct() {
        add_shortcode('bus_search_form', array($this, 'render_search_form'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_bus_search', array($this, 'handle_bus_search'));
        add_action('wp_ajax_nopriv_bus_search', array($this, 'handle_bus_search'));
    }

    public function enqueue_scripts() {
        wp_enqueue_style('bus-search-css', plugin_dir_url(__FILE__) . '../assets/css/bus-search.css');
        wp_enqueue_script('bus-search-js', plugin_dir_url(__FILE__) . '../assets/js/bus-search.js', array('jquery', 'jquery-ui-autocomplete'), null, true);
        wp_localize_script('bus-search-js', 'busSearch', array('ajax_url' => admin_url('admin-ajax.php')));
    }

    public function render_search_form() {
        $cities = $this->get_cities();
        $cities_json = json_encode($cities);

        return '
            <form id="bus-search-form">
                <label for="from-city">From City:</label>
                <input type="text" id="from-city" name="from_city" class="autocomplete" placeholder="Enter departure city" />

                <label for="to-city">To City:</label>
                <input type="text" id="to-city" name="to_city" class="autocomplete" placeholder="Enter destination city" />

                <label for="date">Date:</label>
                <input type="date" id="date" name="date" />

                <button type="submit">Find Tickets</button>
            </form>
            <div id="bus-search-results"></div>
            <script>
                var cities = ' . $cities_json . ';
                jQuery(function($) {
                    $(".autocomplete").autocomplete({
                        source: cities
                    });
                });
            </script>';
    }

    public function handle_bus_search() {
        $from_city = sanitize_text_field($_POST['from_city']);
        $to_city = sanitize_text_field($_POST['to_city']);
        $date = sanitize_text_field($_POST['date']);

        // Query buses based on search criteria
        $args = array(
            'post_type' => 'route',
            'meta_query' => array(
                array(
                    'key' => '_from_city',
                    'value' => $from_city,
                    'compare' => 'LIKE'
                ),
                array(
                    'key' => '_to_city',
                    'value' => $to_city,
                    'compare' => 'LIKE'
                ),
                array(
                    'key' => '_date',
                    'value' => $date,
                    'compare' => 'LIKE'
                )
            )
        );

        $query = new WP_Query($args);
        $results = '';

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $results .= '<div>' . get_the_title() . '</div>';
            }
        } else {
            $results = '<div>No buses found.</div>';
        }

        wp_reset_postdata();
        echo $results;
        wp_die();
    }

    public function get_cities() {
        // Retrieve cities added by admin
        $cities = get_option('bus_ticket_plugin_cities', array());
        return $cities;
    }
}

new Bus_Search();
