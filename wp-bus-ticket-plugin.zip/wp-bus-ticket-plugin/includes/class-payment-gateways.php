<?php
class Payment_Gateways {
    public function __construct() {
        add_filter('woocommerce_payment_gateways', array($this, 'add_payment_gateways'));
    }

    public function add_payment_gateways($methods) {
        $methods[] = 'WC_Gateway_Stripe';
        $methods[] = 'WC_Gateway_Paypal';
        // Add other payment gateways here
        return $methods;
    }
}
new Payment_Gateways();
