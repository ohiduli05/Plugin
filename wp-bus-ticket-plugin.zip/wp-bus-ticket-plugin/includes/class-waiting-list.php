<?php
class Waiting_List {
    public function __construct() {
        add_action('init', array($this, 'create_waiting_list_post_type'));
        add_action('wp_insert_post', array($this, 'check_availability'), 10, 3);
    }

    public function create_waiting_list_post_type() {
        $labels = array(
            'name' => __('Waiting Lists', 'wp-bus-ticket-plugin'),
            'singular_name' => __('Waiting List', 'wp-bus-ticket-plugin')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'supports' => array('title', 'editor', 'custom-fields')
        );

        register_post_type('waiting_list', $args);
    }

    public function check_availability($post_ID, $post, $update) {
        if ($post->post_type !== 'waiting_list') return;

        // Check availability for the specific trip
        $trip_id = get_post_meta($post_ID, '_trip_id', true);
        $available_seats = get_post_meta($trip_id, '_available_seats', true);

        if ($available_seats > 0) {
            // Notify passenger and remove from waiting list
            $passenger_email = get_post_meta($post_ID, '_passenger_email', true);
            wp_mail($passenger_email, 'Seat Available', 'A seat is now available for your trip. Please book your ticket.');

            wp_delete_post($post_ID);
        }
    }
}
new Waiting_List();
