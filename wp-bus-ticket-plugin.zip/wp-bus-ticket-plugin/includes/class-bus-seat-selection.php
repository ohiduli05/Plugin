<?php
class Bus_Seat_Selection {
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('bus_seat_selection', array($this, 'render_seat_selection'));
    }

    public function enqueue_scripts() {
        wp_enqueue_style('bus-seat-selection-css', plugin_dir_url(__FILE__) . '../assets/css/bus-seat-selection.css');
        wp_enqueue_script('bus-seat-selection-js', plugin_dir_url(__FILE__) . '../assets/js/bus-seat-selection.js', array('jquery'), null, true);
    }

    public function render_seat_selection() {
        return '<div id="bus-seat-selection">Seat Selection UI here</div>';
    }
}
