<?php
class Fare_Calculation {
    public function __construct() {
        // Initialization code here
    }

    public function calculate_fare($distance, $price_per_km) {
        return $distance * $price_per_km;
    }
}
