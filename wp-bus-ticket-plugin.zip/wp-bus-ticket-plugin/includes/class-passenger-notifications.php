<?php
class Passenger_Notifications {
    public function __construct() {
        add_action('wp_insert_post', array($this, 'send_notification'), 10, 3);
    }

    public function send_notification($post_ID, $post, $update) {
        if ($post->post_type !== 'booking') return;

        // Get passenger email and booking details
        $passenger_email = get_post_meta($post_ID, '_passenger_email', true);
        $booking_details = get_post($post_ID);

        // Send email
        wp_mail($passenger_email, 'Booking Confirmation', 'Your booking details: ' . print_r($booking_details, true));
    }
}
new Passenger_Notifications();

