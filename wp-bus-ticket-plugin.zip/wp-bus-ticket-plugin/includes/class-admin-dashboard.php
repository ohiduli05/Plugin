<?php
class Admin_Dashboard {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }

    public function add_admin_menu() {
        add_menu_page('Bus Ticket Management', 'Bus Tickets', 'manage_options', 'bus-ticket-management', array($this, 'admin_page'), 'dashicons-tickets', 6);
    }

    public function admin_page() {
        echo '<div class="wrap"><h1>Bus Ticket Management</h1></div>';
    }
}
